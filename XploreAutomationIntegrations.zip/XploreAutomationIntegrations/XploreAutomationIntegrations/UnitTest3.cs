﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XploreAutomationIntegrations {
    public class UnitTest3 {

        [Test]
        [Category("Smoke")]
        public void Test() {
            Console.WriteLine("UnitTest3.Test");
            Console.Beep();
        }
    }
}
