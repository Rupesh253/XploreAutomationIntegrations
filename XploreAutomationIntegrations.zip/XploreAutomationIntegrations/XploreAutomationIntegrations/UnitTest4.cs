﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XploreAutomationIntegrations {
    public class UnitTest4 {

        [Test]
        [Category("Smoke")]
        public void Test() {
            Console.WriteLine("UnitTest4.Test");
        }
    }
}
